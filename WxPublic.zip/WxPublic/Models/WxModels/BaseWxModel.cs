﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WxPublic.Models.WxModels
{
    public class BaseWxModel
    {
        public byte Success { get; set; }
    }
}