﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace WebAPIAndOAuth.Controllers
{
    [Authorize]
    [RoutePrefix("api/Order")]
    public class OrderController : ApiController
    {
        public IHttpActionResult Get()
        {
            return Ok(new {Pid=10,name="ok" });
        }
    }
}
