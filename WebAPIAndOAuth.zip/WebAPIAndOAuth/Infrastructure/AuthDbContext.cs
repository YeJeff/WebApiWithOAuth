﻿using Microsoft.AspNet.Identity.EntityFramework;
using System.Data.Entity;

namespace WebAPIAndOAuth.Infrastructure
{
    public class AuthDbContext:IdentityDbContext<AppUser>
    {
        public AuthDbContext() : base("name=AuthDbContext") { }

        static AuthDbContext() => Database.SetInitializer(new DropCreateDatabaseIfModelChanges());

        public static AuthDbContext Create() => new AuthDbContext();
    }

    class DropCreateDatabaseIfModelChanges : DropCreateDatabaseIfModelChanges<AuthDbContext>
    {
        protected override void Seed(AuthDbContext context)
        {
            base.Seed(context);
        }
    }
}