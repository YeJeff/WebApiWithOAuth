﻿using System;
using System.Web.Http;
using System.Security.Claims;
using System.Threading.Tasks;
using Owin;
using Microsoft.Owin;
using Microsoft.Owin.Cors;
using Microsoft.Owin.Security.OAuth;
using Microsoft.AspNet.Identity.Owin;
using WebAPIAndOAuth.Infrastructure;

[assembly: OwinStartup(typeof(WebAPIAndOAuth.Startup))]

namespace WebAPIAndOAuth
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            // 有关如何配置应用程序的详细信息，请访问 https://go.microsoft.com/fwlink/?LinkID=316888

            app.CreatePerOwinContext(AuthDbContext.Create);
            app.CreatePerOwinContext<AppUserManager>(AppUserManager.Create);



            HttpConfiguration httpConfig = new HttpConfiguration();
            WebApiConfig.Register(httpConfig);

            OAuthConfig(app);

            app.UseCors(CorsOptions.AllowAll);
            app.UseWebApi(httpConfig);
        }

        private void OAuthConfig(IAppBuilder app)
        {
            OAuthAuthorizationServerOptions oauthOptions = new OAuthAuthorizationServerOptions()
            {
                AllowInsecureHttp = true,
                TokenEndpointPath = new PathString("/oauth/token"),
                // AuthorizeEndpointPath=new PathString("/api/Account/ExternalLogin"),
                AccessTokenExpireTimeSpan = TimeSpan.FromSeconds(5),
                Provider = new SimpleAuthorizationServerProvider()
            };

            app.UseOAuthAuthorizationServer(oauthOptions);
            app.UseOAuthBearerAuthentication(new OAuthBearerAuthenticationOptions());
        }
    }

    class SimpleAuthorizationServerProvider : OAuthAuthorizationServerProvider
    {
        public override async Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            context.Validated();
        }
        public override async Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {
            context.OwinContext.Response.Headers.Add("Access-Control-Allow-Origin", new[] { "*" });

            AppUser user = await context.OwinContext.GetUserManager<AppUserManager>().FindAsync(context.UserName, context.Password);

            if (user is null)
            {
                context.SetError("invalid_grant", "The username or password is incorrect");
                return;
            }

            ClaimsIdentity identity = new ClaimsIdentity(context.Options.AuthenticationType);
            identity.AddClaim(new Claim("sub", context.UserName));
            identity.AddClaim(new Claim("role", "user"));

            context.Validated(identity);
        }
    }
}
