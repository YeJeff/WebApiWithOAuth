﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Newtonsoft.Json;

namespace WebApi.Utility
{
    public class JsonHelper
    {
        public static T ToObject<T>(string json)
        {
            T t = JsonConvert.DeserializeObject<T>(json);
            return t;
        }
    }
}