﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApi.Utility
{
    public class WxHelper
    {
        public static string GetGeneralAccessToken()
        {
            string accessToken = CacheHelper.GetCache<string>("g_access_token");

            if (accessToken is null)
            {

            }

            return accessToken;
        }
    }
}