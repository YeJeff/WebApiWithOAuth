﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using System.Web.Caching;

namespace WebApi.Utility
{
    public class CacheHelper
    {
        public static T GetCache<T>(string key)
        {
            T obj = (T)HttpRuntime.Cache.Get(key);
            return obj;
        }

        public static T RemoveCache<T>(string key)
        {
            T obj = (T)HttpRuntime.Cache.Remove(key);
            return obj;
        }

        public static void UpdateOrSetCache<T>(string key, T obj, long expire_seconds)
        {
            try
            {
                HttpRuntime.Cache.Insert(key, obj, null, DateTime.Now.AddSeconds(expire_seconds), TimeSpan.Zero);
            }
            catch(Exception e)
            {

            }
        }
    }
}