﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Configuration;
using System.Threading.Tasks;
using System.Net.Http.Headers;

using WebApi.Utility;
using WebApi.Config;
using WebApi.Models.WxModels;

namespace WebApi.Controllers
{
    [RoutePrefix("api/WxConfig")]
    public class WxConfigController : ApiController
    {
        /// <summary>
        /// 微信公众平台网页授权的方式获得acces_token及openid
        /// </summary>
        /// <param name="code">微信网页授权code</param>
        /// <returns></returns>
        [Route("{code}")]
        public async Task<IHttpActionResult> GetUserID(string code)
        {
            string userID = string.Empty;
            string accessTokenGetUrl = string.Format(WxConfigure.AccessTokenGetUrlTemplate,
                WxConfigure.WxAppid, WxConfigure.WxAppsecret, code);

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage rspMsg = await client.GetAsync(accessTokenGetUrl);

                HttpResponseMessage rspStatus = rspMsg.EnsureSuccessStatusCode();
                if (rspStatus.StatusCode == HttpStatusCode.OK)
                {
                    string rspContent = await rspMsg.Content.ReadAsStringAsync();
                    Code2AccessToken token = JsonHelper.ToObject<Code2AccessToken>(rspContent);
                    userID = token.OpenId;
                }
            }

            return Ok<string>(userID);
        }

        //[]

        
    }
}
